Final updated build
- fixed broken translation entry in I18N
- improved EN/BS toggle
- replaced Median with Best 100s
- translated more popup labels and pagination
- stricter Best 100s parsing
- kept section loader, coverage, and search
