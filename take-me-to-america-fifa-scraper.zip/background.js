// Background service worker — passive capture only, no synthetic scanning

function emptyGame() {
  return { match: null, seats: {}, availability: null, productId: null };
}

let dataUpdatedTimer = null;
function notifyDataUpdated() {
  clearTimeout(dataUpdatedTimer);
  dataUpdatedTimer = setTimeout(() => {
    chrome.runtime.sendMessage({ type: "DATA_UPDATED" }).catch(() => {});
  }, 300);
}

function getStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get(null, (data) => resolve(data || {}));
  });
}

function extractParam(url, param) {
  try {
    const u = new URL(url, "https://dummy.local");
    return u.searchParams.get(param);
  } catch {
    const match = String(url || "").match(new RegExp(`[?&]${param}=([^&]+)`));
    return match ? decodeURIComponent(match[1]) : null;
  }
}

async function ensureGame(perfId) {
  const data = await getStorage();
  const games = data.games || {};
  if (!games[perfId]) games[perfId] = emptyGame();
  return { data, games };
}

async function setActiveGame(perfId) {
  const data = await getStorage();
  if (data.activeGame !== perfId) {
    await chrome.storage.local.set({ activeGame: perfId });
  }
}

async function saveMatchInfo(product) {
  const perfId = String(product?.performanceId || product?.performanceID || "");
  if (!perfId) return;

  const { games } = await ensureGame(perfId);
  games[perfId].match = {
    name: product?.name || "FIFA Match",
    date: product?.date || "",
    currency: product?.currency || "USD",
    performanceId: perfId,
    imgUrl: product?.imgUrl || ""
  };

  await chrome.storage.local.set({ games, activeGame: perfId });
}

async function saveAvailability(perfId, body) {
  if (!perfId) return;
  const { games } = await ensureGame(perfId);

  games[perfId].availability = {
    categories: (body.priceRangeCategories || []).map((c) => ({
      id: c.id,
      name: c.name?.en || c.name || "Unknown",
      rank: c.rank,
      minPrice: c.minPrice,
      maxPrice: c.maxPrice,
      bgColor: c.bgColor,
      textColor: c.textColor
    })),
    globalMin: body.seatMapPriceRanges?.min ?? null,
    globalMax: body.seatMapPriceRanges?.max ?? null
  };

  await chrome.storage.local.set({ games, activeGame: perfId });
}

async function saveSeats(perfId, features) {
  if (!perfId) return;
  const { games } = await ensureGame(perfId);
  const seats = games[perfId].seats || {};

  for (const f of features || []) {
    const p = f?.properties;
    if (!p) continue;

    const seatId = String(p.id ?? `${p.block?.name?.en || p.block?.name || ""}-${p.row || ""}-${p.number || ""}`);
    seats[seatId] = {
      block: p.block?.name?.en || p.block?.name || "",
      area: p.area?.name?.en || p.area?.name || "",
      row: p.row || "",
      seat: p.number || "",
      category: p.seatCategory || p.seatCategoryName || "Unknown",
      categoryId: p.seatCategoryId,
      price: p.amount,
      color: p.color || "",
      exclusive: p.exclusive
    };
  }

  games[perfId].seats = seats;
  await chrome.storage.local.set({ games, activeGame: perfId });
}

async function saveProductId(perfId, productId) {
  if (!perfId || !productId) return;
  const { games } = await ensureGame(perfId);
  games[perfId].productId = productId;
  await chrome.storage.local.set({ games });
}

async function processApiResponse(url, body) {
  if (!body || !url) return;

  if (String(url).includes("google-ecommerce-detail") && body.ecommerceViewProduct) {
    await saveMatchInfo(body.ecommerceViewProduct);
  }

  if (String(url).includes("seatmap/availability") && body.priceRangeCategories) {
    const perfId = extractParam(url, "perfId") || extractParam(url, "performanceId");
    if (perfId) await saveAvailability(perfId, body);
  }

  if (String(url).includes("seats/free") && body.features) {
    const perfId = extractParam(url, "performanceId") || extractParam(url, "perfId");
    const prodId = extractParam(url, "productId");
    if (perfId) {
      await saveSeats(perfId, body.features);
      await setActiveGame(perfId);
      if (prodId) await saveProductId(perfId, prodId);
    }
  }

  if (String(url).includes("seatmap/config")) {
    const perfId = extractParam(url, "performanceId") || extractParam(url, "perfId");
    const prodId = extractParam(url, "productId");
    if (perfId) await setActiveGame(perfId);
    if (perfId && prodId) await saveProductId(perfId, prodId);
  }

  notifyDataUpdated();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "API_RESPONSE") {
    processApiResponse(message.url, message.body);
    return;
  }

  if (message.type === "CLEAR_DATA") {
    chrome.storage.local.clear(() => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "START_SCAN") {
    notifyDataUpdated();
    return;
  }

  if (message.type === "SCAN_PROGRESS") {
    chrome.runtime.sendMessage({
      type: "SCAN_PROGRESS",
      completed: message.completed,
      total: message.total,
      status: message.status,
      eta: message.eta
    }).catch(() => {});
    return;
  }
});
